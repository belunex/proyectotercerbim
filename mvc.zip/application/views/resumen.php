<div class="container-fluid">

    <div class="row">
        <div class="col-sm-1 text center">
        <img src="<?php echo base_url();?>img/sat.png" width="120">
        </div>
        <div class="col-sm-11 text center">
             <h1>Sistema Académico Tiquipaya</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm text-center">
        <h1>Resumen</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6 text-center" id="centro">
        Se vio la necesidad de implementar el presente sistema ya que la consulta actual se la realiza 
manualmente y muchos datos están perdidos o archivados y no se cuenta con datos exactos de 
toda la trayectoria de los estudiantes por su paso en la Unidad Educativa, por ello se desea optimizar
este proceso el cual pueda ser accesible para las áreas que así lo deseen dentro de esta institución.
El sistema Web permitirá que tanto el personal, estudiantes y padres de familia puedan tener acceso 
a una información completa del estado académico de los estudiantes.
Viendo que el tema de salud hoy en día es de gran importancia se implementara un registro de 
estado de salud del estudiante para conocimiento general del mismo.
Además de un reporte conductual que permita ver el estado del estudiante para conocimiento de 
las áreas que así lo requieran.
Un registro que permita ingresar las notas de los estudiantes esto comprenderá la parte académica 
y permitirá tener acceso inmediato a su historial académico en caso de algún área así lo requiera.
La aplicación Móvil permitirá visualizar el reporte de notas a los padres de familia y estudiantes, 
para realizar un seguimiento académico del mismo.

        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>

</div>