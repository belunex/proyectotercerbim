<link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/estilopropio.css">
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6 text-center">

        
            <br>

            <a href="<?php echo base_url();?>index.php/Proyecto/index" class="boton">Principal</a>
            <a href="<?php echo base_url();?>index.php/Proyecto/ejpl" class="boton">Resumen</a>
            <a href="<?php echo base_url();?>index.php/Proyecto/obs" class="boton">Objetivos</a>
            <br>
        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>