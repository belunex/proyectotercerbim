<br>

    <a href="<?php echo base_url();?>index.php/base/index">INICIO</a>
    <a href="<?php echo base_url();?>index.php/base/prod">PRODUCTOS</a>
    <a href="<?php echo base_url();?>index.php/base/cont">CONTACTOS</a>
   