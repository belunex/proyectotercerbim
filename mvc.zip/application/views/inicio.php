<h1>INICIO</h1>

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Formulario</h1>
                        <form actiopn="#" method="POST">

                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="correo" placeholder="Ingresa tu email.">
                            </div>

                            <div class="mb-3">
                            <button type="submint" class="btn btn-primary">Registrarse</button>
                            </div>
                            
                        </form>
                </div>
            </div>

        </div>
