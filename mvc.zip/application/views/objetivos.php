<div class="container-fluid">

    <div class="row">
        <div class="col-sm-1 text center">
        <img src="<?php echo base_url();?>img/sat.png" width="120">
        </div>
        <div class="col-sm-11 text center">
             <h1>Sistema Académico Tiquipaya</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm text-center">
        <h1>Objetivos</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6" id="centro">
            Objetivo General:
        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6" id="contenido">
            Desarrollar un Sistema Móvil y Web Académico para una Unidad Educativa.
        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6" id="centro">
            Objetivos Especificos::
        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3 text-center">
                
        </div>
        <div class="col-sm-6" id="contenido">
        WEB<br>
        • Desarrollar un módulo de gestión de Usuarios.<br>
        • Desarrollar un módulo de gestión de Docente.<br>
        • Desarrollar un módulo de gestión de Estudiantes.<br>
        • Desarrollar un módulo de gestión de Administrativos.<br>
        • Desarrollar un módulo de gestión de Registro Estado de Salud - Estudiantes.<br>
        • Desarrollar un módulo de gestión de Reporte Psicopedagógico.<br>
        • Desarrollar un módulo de gestión de Asignación de cursos.<br>
        • Desarrollar un módulo de gestión de Registro de notas.<br>
        • Desarrollar un módulo de gestión de Padres de Familia.<br>
        MOVIL <br>
        • Desarrollar un módulo de gestión de Usuario.<br>
        • Desarrollar un módulo de gestión de Reporte de notas.<br>
        • Desarrollar un módulo de gestión de Padres de Familia.<br>
        </div>
        <div class="col-sm-3 text-center">
                
        </div>
    </div>

</div>