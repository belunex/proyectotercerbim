
<div class="container shadow-md">

    <div class="row">
        <div class="col-sm-12 text-center">
            <h1>Sistema Academico <br>Tiquipaya</h1>
        </div>
    </div>
    
    <div class="row">
        <div class="col-sm-4 text-center">
                
        </div>
        <div class="col-sm-4 text-center">

            <img src="<?php echo base_url();?>img/sat.png" width="250">

        </div>
        <div class="col-sm-4 text-center">
                
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 text-center">
            "Descubre tu potencial y alcanza tus metas con <br>nuestro sistema académico de excelencia."
        </div>
    </div>
</div>